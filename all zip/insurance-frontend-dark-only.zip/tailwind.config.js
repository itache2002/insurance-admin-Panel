/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#e9fbf4',
          100: '#c9f4e1',
          200: '#95e7c7',
          300: '#5dd2aa',
          400: '#32b990',
          500: '#22a07c',
          600: '#1d8269',
          700: '#196858',
          800: '#154f46',
          900: '#113f3a'
        }
      }
    }
  },
  plugins: []
}
