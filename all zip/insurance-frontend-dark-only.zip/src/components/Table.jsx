import React, { useMemo, useState } from 'react'

export default function Table({ columns, data, keyField='id', searchable=true, pageSizeOptions=[5,10,20,50] }) {
  const [q, setQ] = useState('')
  const [sortKey, setSortKey] = useState(columns[0]?.key || null)
  const [sortDir, setSortDir] = useState('asc') // 'asc' | 'desc'
  const [pageSize, setPageSize] = useState(10)
  const [page, setPage] = useState(1)

  const filtered = useMemo(() => {
    if (!q) return data
    const needle = q.toLowerCase()
    return data.filter(row => columns.some(col => String(row[col.key] ?? '').toLowerCase().includes(needle)))
  }, [q, data, columns])

  const sorted = useMemo(() => {
    if (!sortKey) return filtered
    const copy = [...filtered]
    copy.sort((a,b) => {
      const va = a[sortKey]; const vb = b[sortKey]
      if (va == null && vb != null) return sortDir === 'asc' ? -1 : 1
      if (va != null && vb == null) return sortDir === 'asc' ? 1 : -1
      if (va == null && vb == null) return 0
      const sa = String(va).toLowerCase(), sb = String(vb).toLowerCase()
      if (sa < sb) return sortDir === 'asc' ? -1 : 1
      if (sa > sb) return sortDir === 'asc' ? 1 : -1
      return 0
    })
    return copy
  }, [filtered, sortKey, sortDir])

  const total = sorted.length
  const totalPages = Math.max(1, Math.ceil(total / pageSize))
  const currentPage = Math.min(page, totalPages)
  const startIndex = (currentPage - 1) * pageSize
  const pageRows = sorted.slice(startIndex, startIndex + pageSize)

  function onHeaderClick(key) {
    if (key === sortKey) setSortDir(d => d === 'asc' ? 'desc' : 'asc')
    else { setSortKey(key); setSortDir('asc') }
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2 justify-between">
        {searchable && (
          <div className="flex items-center gap-2">
            <input className="input" placeholder="Search…" value={q} onChange={e=>{ setQ(e.target.value); setPage(1) }} />
            {q && <button className="btn-outline" onClick={()=>setQ('')}>Clear</button>}
          </div>
        )}
        <div className="flex items-center gap-2 text-sm text-gray-400">
          <span>Rows per page</span>
          <select className="input" value={pageSize} onChange={e=>{ setPageSize(Number(e.target.value)); setPage(1) }}>
            {pageSizeOptions.map(n => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>
      </div>

      <div className="table-wrap">
        <table className="table zebra">
          <thead>
            <tr>
              {columns.map(col => (
                <th key={col.key} onClick={()=>onHeaderClick(col.key)} style={{cursor:'pointer'}}>
                  <div className="flex items-center gap-2">
                    <span>{col.title}</span>
                    {sortKey === col.key && <span className="text-gray-400">{sortDir === 'asc' ? '▲' : '▼'}</span>}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageRows.map(row => (
              <tr key={row[keyField] ?? JSON.stringify(row)}>
                {columns.map(col => (
                  <td key={col.key}>{col.render ? col.render(row[col.key], row) : row[col.key]}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between text-sm text-gray-400">
        <div>
          {total === 0 ? 'No results' : `Showing ${startIndex + 1}-${Math.min(startIndex + pageSize, total)} of ${total}`}
        </div>
        <div className="flex items-center gap-2">
          <button className="btn-outline" disabled={currentPage <= 1} onClick={()=>setPage(p=>Math.max(1, p-1))}>Prev</button>
          <span>Page {currentPage} / {totalPages}</span>
          <button className="btn-outline" disabled={currentPage >= totalPages} onClick={()=>setPage(p=>Math.min(totalPages, p+1))}>Next</button>
        </div>
      </div>
    </div>
  )
}
