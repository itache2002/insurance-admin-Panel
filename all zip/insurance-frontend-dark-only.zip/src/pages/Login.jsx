import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { http, setAuth } from '../utils/api'

export default function Login() {
  const [email, setEmail] = useState('admin@example.com')
  const [password, setPassword] = useState('Admin@123')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const onSubmit = async (e) => {
    e.preventDefault()
    setLoading(true); setError('')
    try {
      const data = await http('/auth/login', { method:'POST', body: { email, password } })
      setAuth(data)
      navigate('/dashboard')
    } catch (e) {
      setError(e.message)
    } finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen grid place-items-center p-4 bg-gray-950">
      <div className="card w-full max-w-md p-6">
        <h1 className="text-2xl font-semibold mb-1">Welcome back</h1>
        <p className="text-gray-400 mb-6">Sign in to your account</p>

        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label className="label" htmlFor="email">Email</label>
            <input id="email" type="email" required className="input" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" />
          </div>
          <div>
            <label className="label" htmlFor="password">Password</label>
            <input id="password" type="password" required className="input" value={password} onChange={e=>setPassword(e.target.value)} />
          </div>
          {error && <div className="text-red-400 text-sm">{error}</div>}
          <button className="btn w-full" disabled={loading}>{loading ? 'Signing in…' : 'Sign in'}</button>
        </form>
      </div>
    </div>
  )
}
