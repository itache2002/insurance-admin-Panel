import React, { useEffect, useState } from 'react'
import { http } from '../../utils/api'
import Table from '../../components/Table'

export default function SuperUsers() {
  const [list, setList] = useState([])
  const [form, setForm] = useState({ role:'employee', name:'', email:'', phone_no:'', password:'', pan_number:'', aadhaar_number:'' })
  const [bank, setBank] = useState({ name:'', ifsc:'', account_no:'' })
  const [education, setEdu] = useState({ x10:'', x12:'', degree:'' })
  const [busy, setBusy] = useState(false)

  async function load() {
    const data = await http('/admin/overview')
    setList(data.employees)
  }
  useEffect(()=>{ load() }, [])

  async function submit(e) {
    e.preventDefault()
    setBusy(true)
    try {
      await http('/admin/users', { method:'POST', body:{ ...form, bank, education } })
      setForm({ role:'employee', name:'', email:'', phone_no:'', password:'', pan_number:'', aadhaar_number:'' })
      await load()
    } finally { setBusy(false) }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Employees & Admins</h1>

      <div className="card p-4">
        <h2 className="font-semibold mb-3">Create</h2>
        <form onSubmit={submit} className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="label">Role</label>
            <select className="input" value={form.role} onChange={e=>setForm({...form, role:e.target.value})}>
              <option value="employee">Employee</option>
              <option value="super_admin">Super Admin</option>
            </select>
          </div>
          <div><label className="label">Name</label><input required className="input" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} /></div>
          <div><label className="label">Email</label><input type="email" required className="input" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} /></div>
          <div><label className="label">Phone</label><input type="tel" className="input" value={form.phone_no} onChange={e=>setForm({...form, phone_no:e.target.value})} /></div>
          <div><label className="label">Password</label><input required className="input" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} /></div>
          <div><label className="label">PAN</label><input className="input" value={form.pan_number} onChange={e=>setForm({...form, pan_number:e.target.value})} /></div>
          <div><label className="label">Aadhaar</label><input className="input" value={form.aadhaar_number} onChange={e=>setForm({...form, aadhaar_number:e.target.value})} /></div>
          <div><label className="label">Bank Name</label><input className="input" value={bank.name} onChange={e=>setBank({...bank, name:e.target.value})} /></div>
          <div><label className="label">IFSC</label><input className="input" value={bank.ifsc} onChange={e=>setBank({...bank, ifsc:e.target.value})} /></div>
          <div><label className="label">Account No</label><input className="input" value={bank.account_no} onChange={e=>setBank({...bank, account_no:e.target.value})} /></div>
          <div><label className="label">10th</label><input className="input" value={education.x10} onChange={e=>setEdu({...education, x10:e.target.value})} /></div>
          <div><label className="label">12th</label><input className="input" value={education.x12} onChange={e=>setEdu({...education, x12:e.target.value})} /></div>
          <div><label className="label">Degree</label><input className="input" value={education.degree} onChange={e=>setEdu({...education, degree:e.target.value})} /></div>
          <div className="sm:col-span-2">
            <button className="btn" disabled={busy}>{busy ? 'Saving…' : 'Create'}</button>
          </div>
        </form>
      </div>

      <Table columns={[
        { key:'name', title:'Name' },
        { key:'email', title:'Email' },
        { key:'phone_no', title:'Phone' },
      ]} data={list} />
    </div>
  )
}
