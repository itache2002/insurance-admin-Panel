import React, { useState } from 'react'
import { http } from '../../utils/api'
import Table from '../../components/Table'

export default function SuperFinance() {
  const [form, setForm] = useState({ user_id:'', month:'2025-08', net_premium:'', net_commission:'' })
  const [list, setList] = useState([])

  async function submit(e) {
    e.preventDefault()
    await http('/finance/entries', { method:'POST', body: form })
    alert('Finance entry saved')
    if (form.user_id) {
      const rows = await http(`/finance/user/${form.user_id}`)
      setList(rows)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Finance</h1>
      <div className="card p-4">
        <form onSubmit={submit} className="grid sm:grid-cols-4 gap-4">
          <div><label className="label">User ID</label><input className="input" value={form.user_id} onChange={e=>setForm({...form, user_id:e.target.value})}/></div>
          <div><label className="label">Month</label><input className="input" value={form.month} onChange={e=>setForm({...form, month:e.target.value})}/></div>
          <div><label className="label">Net Premium</label><input type="number" className="input" value={form.net_premium} onChange={e=>setForm({...form, net_premium:e.target.value})}/></div>
          <div><label className="label">Net Commission</label><input type="number" className="input" value={form.net_commission} onChange={e=>setForm({...form, net_commission:e.target.value})}/></div>
          <div className="sm:col-span-4">
            <button className="btn">Save / Update</button>
          </div>
        </form>
      </div>

      <Table columns={[
        { key:'month', title:'Month' },
        { key:'net_premium', title:'Net Premium' },
        { key:'net_commission', title:'Net Commission' },
      ]} data={list} keyField="month" />
    </div>
  )
}
