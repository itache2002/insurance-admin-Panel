import React, { useEffect, useState } from 'react'
import { http } from '../../utils/api'
import Table from '../../components/Table'

export default function SuperAgents() {
  const [list, setList] = useState([])
  const [form, setForm] = useState({ name:'', email:'', phone_no:'', password:'', pan_number:'', aadhaar_number:'', onboarding_employee_id:'', salary_monthly:'' })
  const [bank, setBank] = useState({ name:'', ifsc:'', account_no:'' })
  const [education, setEdu] = useState({ x10:'', x12:'', degree:'' })
  const [busy, setBusy] = useState(false)

  async function load() {
    const data = await http('/admin/overview')
    setList(data.agents)
  }
  useEffect(()=>{ load() }, [])

  async function submit(e) {
    e.preventDefault()
    setBusy(true)
    try {
      await http('/admin/agents', { method:'POST', body:{ ...form, bank, education } })
      setForm({ name:'', email:'', phone_no:'', password:'', pan_number:'', aadhaar_number:'', onboarding_employee_id:'', salary_monthly:'' })
      await load()
    } finally { setBusy(false) }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Agents</h1>
      <div className="card p-4">
        <h2 className="font-semibold mb-3">Create Agent</h2>
        <form onSubmit={submit} className="grid sm:grid-cols-2 gap-4">
          <div><label className="label">Name</label><input required className="input" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} /></div>
          <div><label className="label">Email</label><input required type="email" className="input" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} /></div>
          <div><label className="label">Phone</label><input type="tel" className="input" value={form.phone_no} onChange={e=>setForm({...form, phone_no:e.target.value})} /></div>
          <div><label className="label">Password</label><input required className="input" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} /></div>
          <div><label className="label">PAN</label><input className="input" value={form.pan_number} onChange={e=>setForm({...form, pan_number:e.target.value})} /></div>
          <div><label className="label">Aadhaar</label><input className="input" value={form.aadhaar_number} onChange={e=>setForm({...form, aadhaar_number:e.target.value})} /></div>
          <div><label className="label">Onboarded by (Emp ID)</label><input className="input" value={form.onboarding_employee_id} onChange={e=>setForm({...form, onboarding_employee_id:e.target.value})} /></div>
          <div><label className="label">Salary (Monthly)</label><input type="number" className="input" value={form.salary_monthly} onChange={e=>setForm({...form, salary_monthly:e.target.value})} /></div>
          <div><label className="label">Bank Name</label><input className="input" value={bank.name} onChange={e=>setBank({...bank, name:e.target.value})} /></div>
          <div><label className="label">IFSC</label><input className="input" value={bank.ifsc} onChange={e=>setBank({...bank, ifsc:e.target.value})} /></div>
          <div><label className="label">Account No</label><input className="input" value={bank.account_no} onChange={e=>setBank({...bank, account_no:e.target.value})} /></div>
          <div><label className="label">10th</label><input className="input" value={education.x10} onChange={e=>setEdu({...education, x10:e.target.value})} /></div>
          <div><label className="label">12th</label><input className="input" value={education.x12} onChange={e=>setEdu({...education, x12:e.target.value})} /></div>
          <div><label className="label">Degree</label><input className="input" value={education.degree} onChange={e=>setEdu({...education, degree:e.target.value})} /></div>
          <div className="sm:col-span-2"><button className="btn" disabled={busy}>{busy ? 'Saving…' : 'Create Agent'}</button></div>
        </form>
      </div>

      <Table columns={[
        { key:'name', title:'Name' },
        { key:'email', title:'Email' },
        { key:'phone_no', title:'Phone' },
        { key:'onboarding_employee_id', title:'Onboarded By (Email)', render: (v)=> (list.find(x=>x.id===v) ? list.find(x=>x.id===v).email : '—') }
      ]} data={list} />
    </div>
  )
}
