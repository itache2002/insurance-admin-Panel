# Insurance Backend (Node.js + Express + PostgreSQL)

## Quick Start
1. Install dependencies
```bash
npm i
```
2. Copy environment and edit
```bash
cp .env.example .env
```
3. Create Postgres database & user, then set .env
4. Run migrations & seed
```bash
npm run migrate
npm run seed
```
5. Start server
```bash
npm run dev
```

## Auth
- POST `/api/auth/register-initial-superadmin` { name, email, password } (one-time bootstrap)
- POST `/api/auth/login` { email, password } → `{ token }`

Send `Authorization: Bearer <token>` header for protected routes.

## Roles
- super_admin
- employee
- agent

## Key Endpoints
- **Admin (super_admin)**
  - POST `/api/admin/users` (create employee or super_admin)
  - POST `/api/admin/agents`
  - GET `/api/admin/overview`
  - POST `/api/admin/salary/:userId` { salary_monthly }
- **Employee**
  - POST `/api/employee/agents`
  - GET `/api/employee/me`
  - GET `/api/employee/agents`
  - GET `/api/employee/agents/customers`
  - GET `/api/employee/agents/:agentId/targets`
- **Agent**
  - GET `/api/agent/me`
- **Customers**
  - POST `/api/customers` (agent)
  - PATCH `/api/customers/:id/status`
  - GET `/api/customers/mine` (agent)
  - GET `/api/customers` (super_admin/employee)
- **Targets**
  - POST `/api/targets` (super_admin) upsert by (user_id, month)
  - GET `/api/targets/user/:userId`
- **Finance**
  - POST `/api/finance/entries` (super_admin) upsert by (user_id, month)
  - GET `/api/finance/user/:userId`
- **Analytics**
  - GET `/api/analytics/basic` (role-aware summary)

## Notes
- Month is stored as `YYYY-MM` text for simplicity.
- Password defaults to `ChangeMe123!` if not provided when creating users/agents – rotate it later.
- This is a clean foundation; add pagination, validation, and finer-grained access as needed.
