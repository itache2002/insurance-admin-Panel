export function notFound(_req, res, _next) {
  res.status(404).json({ error: 'Not found' });
}

export function errorHandler(err, _req, res, _next) {
  console.error(err);
  if (err.code === '23505') {
    return res.status(400).json({ error: 'Duplicate value', detail: err.detail });
  }
  res.status(err.status || 500).json({ error: err.message || 'Server error' });
}
