import express from 'express';
import { pool, sql } from '../db.js';
import { requireAuth, requireRole, Roles } from '../utils/auth.js';

const router = express.Router();
router.use(requireAuth, requireRole(Roles.AGENT, Roles.SUPER_ADMIN, Roles.EMPLOYEE));

/** Agent profile */
router.get('/me', async (req, res, next) => {
  try {
    const me = await pool.one(sql`SELECT id, name, email, phone_no FROM users WHERE id = ${req.user.id}`);
    res.json(me);
  } catch (e) { next(e); }
});

export default router;
