import express from 'express';
import { pool, sql } from '../db.js';
import { requireAuth, requireRole, Roles } from '../utils/auth.js';

const router = express.Router();

/** Set targets for both employees and agents (Super Admin only) */
router.post('/', requireAuth, requireRole(Roles.SUPER_ADMIN), async (req, res, next) => {
  try {
    const { user_id, month, target_policies, target_premium } = req.body;
    const row = await pool.one(sql`
      INSERT INTO targets (user_id, month, target_policies, target_premium)
      VALUES (${user_id}, ${month}, ${target_policies || 0}, ${target_premium || 0})
      ON CONFLICT (user_id, month) DO UPDATE SET target_policies = EXCLUDED.target_policies, target_premium = EXCLUDED.target_premium
      RETURNING *`);
    res.json(row);
  } catch (e) { next(e); }
});

/** View targets of a user (Employee can see their onboarded agents too) */
router.get('/user/:userId', requireAuth, requireRole(Roles.SUPER_ADMIN, Roles.EMPLOYEE, Roles.AGENT), async (req, res, next) => {
  try {
    const { userId } = req.params;
    const rows = await pool.any(sql`SELECT * FROM targets WHERE user_id = ${userId} ORDER BY month DESC`);
    res.json(rows);
  } catch (e) { next(e); }
});

export default router;
