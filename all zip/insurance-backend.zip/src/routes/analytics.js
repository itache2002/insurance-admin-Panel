import express from 'express';
import { pool, sql } from '../db.js';
import { requireAuth, requireRole, Roles } from '../utils/auth.js';

const router = express.Router();
router.use(requireAuth, requireRole(Roles.SUPER_ADMIN, Roles.EMPLOYEE, Roles.AGENT));

/** Basic analytics (role-aware) */
router.get('/basic', async (req, res, next) => {
  try {
    const role = req.user.role;

    if (role === 'super_admin') {
      const stats = await pool.one(sql`
        SELECT
          (SELECT COUNT(*) FROM users WHERE role='employee')::int AS employees,
          (SELECT COUNT(*) FROM users WHERE role='agent')::int AS agents,
          (SELECT COUNT(*) FROM customers)::int AS customers,
          (SELECT COALESCE(SUM(net_premium),0) FROM finance_entries)::float AS total_premium,
          (SELECT COALESCE(SUM(net_commission),0) FROM finance_entries)::float AS total_commission
      `);
      return res.json({ scope: 'global', stats });
    }

    if (role === 'employee') {
      const userId = req.user.id;
      const stats = await pool.one(sql`
        SELECT
          (SELECT COUNT(*) FROM users WHERE role='agent' AND onboarding_employee_id = ${userId})::int AS my_agents,
          (SELECT COUNT(*) FROM customers c JOIN users a ON a.id=c.agent_id WHERE a.onboarding_employee_id = ${userId})::int AS my_customers,
          (SELECT COALESCE(SUM(f.net_premium),0) FROM finance_entries f JOIN users a ON a.id=f.user_id WHERE a.onboarding_employee_id=${userId})::float AS total_premium,
          (SELECT COALESCE(SUM(f.net_commission),0) FROM finance_entries f JOIN users a ON a.id=f.user_id WHERE a.onboarding_employee_id=${userId})::float AS total_commission
      `);
      return res.json({ scope: 'employee', stats });
    }

    if (role === 'agent') {
      const userId = req.user.id;
      const stats = await pool.one(sql`
        SELECT
          (SELECT COUNT(*) FROM customers WHERE agent_id=${userId})::int AS my_customers,
          (SELECT COALESCE(SUM(net_premium),0) FROM finance_entries WHERE user_id=${userId})::float AS my_premium,
          (SELECT COALESCE(SUM(net_commission),0) FROM finance_entries WHERE user_id=${userId})::float AS my_commission
      `);
      return res.json({ scope: 'agent', stats });
    }

    res.json({});
  } catch (e) { next(e); }
});

export default router;
