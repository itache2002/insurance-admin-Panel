import express from 'express';
import { pool, sql } from '../db.js';
import { requireAuth, requireRole, Roles } from '../utils/auth.js';

const router = express.Router();

/** Create customer (Agent only) */
router.post('/', requireAuth, requireRole(Roles.AGENT, Roles.SUPER_ADMIN), async (req, res, next) => {
  try {
    const { name, age, number_of_children, parents, status, aadhaar_number, pan_number } = req.body;
    const row = await pool.one(sql`
      INSERT INTO customers (agent_id, name, age, number_of_children, parents, status, aadhaar_number, pan_number)
      VALUES (${req.user.id}, ${name}, ${age}, ${number_of_children}, ${parents}, ${status || 'pending'}, ${aadhaar_number}, ${pan_number})
      RETURNING *`);
    res.json(row);
  } catch (e) { next(e); }
});

/** Change status of customer (Agent who owns or Super Admin) */
router.patch('/:id/status', requireAuth, requireRole(Roles.AGENT, Roles.SUPER_ADMIN, Roles.EMPLOYEE), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const row = await pool.one(sql`UPDATE customers SET status=${status} WHERE id=${id} RETURNING *`);
    res.json(row);
  } catch (e) { next(e); }
});

/** View all customers for current agent */
router.get('/mine', requireAuth, requireRole(Roles.AGENT), async (req, res, next) => {
  try {
    const rows = await pool.any(sql`SELECT * FROM customers WHERE agent_id = ${req.user.id} ORDER BY id DESC`);
    res.json(rows);
  } catch (e) { next(e); }
});

/** Admin/Employee can list with filters */
router.get('/', requireAuth, requireRole(Roles.SUPER_ADMIN, Roles.EMPLOYEE), async (req, res, next) => {
  try {
    const rows = await pool.any(sql`SELECT * FROM customers ORDER BY id DESC`);
    res.json(rows);
  } catch (e) { next(e); }
});

export default router;
