import express from 'express';
import { pool, sql } from '../db.js';
import { requireAuth, requireRole, Roles } from '../utils/auth.js';

const router = express.Router();

/** Add Net premiums & Net commissions for a user in a month */
router.post('/entries', requireAuth, requireRole(Roles.SUPER_ADMIN), async (req, res, next) => {
  try {
    const { user_id, month, net_premium, net_commission } = req.body;
    const row = await pool.one(sql`
      INSERT INTO finance_entries (user_id, month, net_premium, net_commission)
      VALUES (${user_id}, ${month}, ${net_premium || 0}, ${net_commission || 0})
      ON CONFLICT (user_id, month) DO UPDATE SET net_premium=EXCLUDED.net_premium, net_commission=EXCLUDED.net_commission
      RETURNING *`);
    res.json(row);
  } catch (e) { next(e); }
});

/** Get monthly finance summary per user */
router.get('/user/:userId', requireAuth, requireRole(Roles.SUPER_ADMIN, Roles.EMPLOYEE, Roles.AGENT), async (req, res, next) => {
  try {
    const { userId } = req.params;
    const rows = await pool.any(sql`SELECT * FROM finance_entries WHERE user_id = ${userId} ORDER BY month DESC`);
    res.json(rows);
  } catch (e) { next(e); }
});

export default router;
