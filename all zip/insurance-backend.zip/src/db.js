import { createPool, sql } from 'slonik';

const pool = await createPool({
  connectionString: `postgresql://${process.env.PGUSER}:${process.env.PGPASSWORD}@${process.env.PGHOST}:${process.env.PGPORT}/${process.env.PGDATABASE}`,
  ssl: process.env.PGSSL === 'require' ? { rejectUnauthorized: false } : null
});

export { pool, sql };
