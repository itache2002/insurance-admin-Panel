import express from 'express';
import authRouter from './routes/auth.js';
import adminRouter from './routes/admin.js';
import employeeRouter from './routes/employee.js';
import agentRouter from './routes/agent.js';
import customerRouter from './routes/customer.js';
import analyticsRouter from './routes/analytics.js';
import targetRouter from './routes/targets.js';
import financeRouter from './routes/finance.js';

export async function createRouter() {
  const router = express.Router();
  router.use('/auth', authRouter);
  router.use('/admin', adminRouter);
  router.use('/employee', employeeRouter);
  router.use('/agent', agentRouter);
  router.use('/customers', customerRouter);
  router.use('/analytics', analyticsRouter);
  router.use('/targets', targetRouter);
  router.use('/finance', financeRouter);
  return router;
}
