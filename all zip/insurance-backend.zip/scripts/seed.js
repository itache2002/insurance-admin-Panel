import { pool, sql } from '../src/db.js';
import { hashPassword } from '../src/utils/auth.js';

async function run() {
  const adminEmail = 'admin@example.com';
  const pass = await hashPassword('Admin@123');
  const exists = await pool.maybeOne(sql`SELECT id FROM users WHERE email=${adminEmail}`);
  if (!exists) {
    await pool.query(sql`INSERT INTO users (role, name, email, password_hash) VALUES ('super_admin','Root Admin', ${adminEmail}, ${pass})`);
    console.log('Seeded super admin:', adminEmail, 'password=Admin@123');
  } else {
    console.log('Super admin already exists');
  }
  process.exit(0);
}

run().catch(e => { console.error(e); process.exit(1); });
