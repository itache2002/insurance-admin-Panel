import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { sql, pool } from '../src/db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function run() {
  const dir = path.resolve(__dirname, '..', 'sql');
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort();
  for (const f of files) {
    const p = path.join(dir, f);
    const sqlText = fs.readFileSync(p, 'utf8');
    console.log('Running migration:', f);
    await pool.query(sql.unsafe(sqlText));
  }
  console.log('All migrations applied.');
  process.exit(0);
}

run().catch(e => { console.error(e); process.exit(1); });
