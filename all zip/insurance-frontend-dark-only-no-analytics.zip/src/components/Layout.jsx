import React, { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { getUser, clearAuth } from '../utils/api'
const NavLink = ({ to, children }) => {
  const loc = useLocation()
  const active = loc.pathname.startsWith(to)
  return <Link to={to} className={`navlink ${active ? 'active' : ''}`}>{children}</Link>
}
export default function Layout({ children }) {
  const user = getUser()
  const navigate = useNavigate()
  const [open, setOpen] = useState(true)
  return (
    <div className="min-h-screen grid" style={{ gridTemplateColumns: open ? '260px 1fr' : '0px 1fr' }}>
      <aside className={`sidebar p-4 transition-all overflow-hidden ${open ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        <div className="flex items-center gap-2 mb-6">
          <div className="h-10 w-10 rounded-xl bg-brand-600 text-white grid place-items-center font-bold">IN</div>
          <div>
            <div className="font-semibold">Insurance Admin</div>
            <div className="text-xs text-gray-400">{user?.role}</div>
          </div>
        </div>
        <nav className="space-y-1">
          <NavLink to="/dashboard">Dashboard</NavLink>
          {(user?.role === 'super_admin') && (<>
            <div className="mt-3 text-xs uppercase text-gray-500 px-2">Super Admin</div>
            <NavLink to="/super/overview">Overview</NavLink>
            <NavLink to="/super/users">Employees & Admins</NavLink>
            <NavLink to="/super/agents">Agents</NavLink>
            <NavLink to="/super/targets">Targets</NavLink>
            <NavLink to="/super/finance">Finance</NavLink>
            <NavLink to="/customers">Customers</NavLink>
          </>)}
          {(user?.role === 'employee') && (<>
            <div className="mt-3 text-xs uppercase text-gray-500 px-2">Employee</div>
            <NavLink to="/employee/profile">My Profile</NavLink>
            <NavLink to="/employee/agents">My Agents</NavLink>
            <NavLink to="/employee/agents-customers">Agents' Customers</NavLink>
          </>)}
          {(user?.role === 'agent') && (<>
            <div className="mt-3 text-xs uppercase text-gray-500 px-2">Agent</div>
            <NavLink to="/agent/profile">My Profile</NavLink>
            <NavLink to="/agent/customers">My Customers</NavLink>
            <NavLink to="/agent/customers/new">New Customer</NavLink>
          </>)}
        </nav>
        <div className="mt-6 grid gap-2">
          <button className="btn-outline w-full" onClick={()=>{ clearAuth(); navigate('/login'); }}>Logout</button>
        </div>
      </aside>
      <main className="p-0">
        <div className="topbar">
          <div className="px-4 py-3 flex items-center justify-between">
            <button className="btn-ghost" onClick={()=>setOpen(o=>!o)} aria-label="Toggle sidebar">{open ? '☰ Hide' : '☰ Menu'}</button>
            <div className="text-sm text-gray-400">Signed in as <span className="font-medium text-gray-200">{user?.email}</span></div>
          </div>
        </div>
        <div className="p-6">{children}</div>
      </main>
    </div>
  )
}
