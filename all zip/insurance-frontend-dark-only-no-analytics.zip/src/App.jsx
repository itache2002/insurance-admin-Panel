import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Layout from './components/Layout.jsx'
import Protected from './components/Protected.jsx'
import Login from './pages/Login.jsx'
import Dashboard from './pages/Dashboard.jsx'
import SuperOverview from './pages/super/Overview.jsx'
import SuperUsers from './pages/super/Users.jsx'
import SuperAgents from './pages/super/Agents.jsx'
import SuperTargets from './pages/super/Targets.jsx'
import SuperFinance from './pages/super/Finance.jsx'
import Customers from './pages/Customers.jsx'
import EmployeeProfile from './pages/employee/Profile.jsx'
import EmployeeAgents from './pages/employee/Agents.jsx'
import EmployeeAgentsCustomers from './pages/employee/AgentsCustomers.jsx'
import AgentProfile from './pages/agent/Profile.jsx'
import AgentCustomers from './pages/agent/Customers.jsx'
import AgentNewCustomer from './pages/agent/NewCustomer.jsx'

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Protected><Layout><Dashboard/></Layout></Protected>} />
      <Route path="/dashboard" element={<Protected><Layout><Dashboard/></Layout></Protected>} />
      {/* Super Admin */}
      <Route path="/super/overview" element={<Protected><Layout><SuperOverview/></Layout></Protected>} />
      <Route path="/super/users" element={<Protected><Layout><SuperUsers/></Layout></Protected>} />
      <Route path="/super/agents" element={<Protected><Layout><SuperAgents/></Layout></Protected>} />
      <Route path="/super/targets" element={<Protected><Layout><SuperTargets/></Layout></Protected>} />
      <Route path="/super/finance" element={<Protected><Layout><SuperFinance/></Layout></Protected>} />
      <Route path="/customers" element={<Protected><Layout><Customers/></Layout></Protected>} />
      {/* Employee */}
      <Route path="/employee/profile" element={<Protected><Layout><EmployeeProfile/></Layout></Protected>} />
      <Route path="/employee/agents" element={<Protected><Layout><EmployeeAgents/></Layout></Protected>} />
      <Route path="/employee/agents-customers" element={<Protected><Layout><EmployeeAgentsCustomers/></Layout></Protected>} />
      {/* Agent */}
      <Route path="/agent/profile" element={<Protected><Layout><AgentProfile/></Layout></Protected>} />
      <Route path="/agent/customers" element={<Protected><Layout><AgentCustomers/></Layout></Protected>} />
      <Route path="/agent/customers/new" element={<Protected><Layout><AgentNewCustomer/></Layout></Protected>} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}
