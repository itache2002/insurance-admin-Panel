import React, { useEffect, useState, useMemo } from 'react'
import { http } from '../../utils/api'
import Table from '../../components/Table'
export default function SuperOverview() {
  const [data, setData] = useState(null)
  useEffect(() => { (async () => setData(await http('/admin/overview')))() }, [])
  const empById = useMemo(() => Object.fromEntries((data?.employees || []).map(e => [e.id, e])), [data])
  const agentById = useMemo(() => Object.fromEntries((data?.agents || []).map(a => [a.id, a])), [data])
  if (!data) return <div>Loading...</div>
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Company Overview</h1>
      <div className="grid lg:grid-cols-2 gap-6">
        <div>
          <h2 className="font-semibold mb-2">Employees</h2>
          <Table columns={[{key:'name',title:'Name'},{key:'email',title:'Email'},{key:'phone_no',title:'Phone'}]} data={data.employees} />
        </div>
        <div>
          <h2 className="font-semibold mb-2">Agents</h2>
          <Table columns={[{key:'name',title:'Name'},{key:'email',title:'Email'},{key:'phone_no',title:'Phone'},{key:'onboarding_employee_id',title:'Onboarded By (Email)',render:(v)=>empById[v]?.email||'—'}]} data={data.agents} />
        </div>
        <div className="lg:col-span-2">
          <h2 className="font-semibold mb-2">Customers</h2>
          <Table columns={[{key:'name',title:'Name'},{key:'status',title:'Status'},{key:'agent_id',title:'Agent (Email)',render:(v)=>agentById[v]?.email||'—'}]} data={data.customers} />
        </div>
      </div>
    </div>
  )
}
