import React, { useEffect, useState } from 'react'
import { http } from '../../utils/api'
export default function AgentProfile() {
  const [me, setMe] = useState(null)
  useEffect(()=>{ (async()=> setMe(await http('/agent/me')))() }, [])
  if (!me) return <div>Loading...</div>
  return (
    <div className="space-y-2">
      <h1 className="text-2xl font-semibold">My Profile</h1>
      <div className="card p-4 grid sm:grid-cols-2 gap-2">
        <div><b>Name:</b> {me.name}</div>
        <div><b>Email:</b> {me.email}</div>
        <div><b>Phone:</b> {me.phone_no}</div>
      </div>
    </div>
  )
}
