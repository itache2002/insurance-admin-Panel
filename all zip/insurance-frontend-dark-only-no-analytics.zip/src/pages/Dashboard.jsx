import React, { useEffect, useMemo, useState } from 'react'
import { http, getUser } from '../utils/api'
import Table from '../components/Table'

function Stat({ label, value }) {
  return (
    <div className="card p-4">
      <div className="text-sm text-gray-400">{label}</div>
      <div className="text-2xl font-semibold">{value}</div>
    </div>
  )
}

export default function Dashboard() {
  const user = getUser()
  const [stats, setStats] = useState(null)
  const [overview, setOverview] = useState(null)
  const [myAgents, setMyAgents] = useState([])
  const [myAgentsCustomers, setMyAgentsCustomers] = useState([])

  useEffect(() => {
    (async () => {
      const data = await http('/analytics/basic')
      setStats(data.stats)
      if (user.role === 'super_admin') setOverview(await http('/admin/overview'))
      if (user.role === 'employee') {
        setMyAgents(await http('/employee/agents'))
        setMyAgentsCustomers(await http('/employee/agents/customers'))
      }
    })()
  }, [user.role])

  const customersPerAgent = useMemo(() => {
    if (user.role !== 'employee') return {}
    const map = {}
    for (const c of myAgentsCustomers) map[c.agent_id] = (map[c.agent_id] || 0) + 1
    return map
  }, [user.role, myAgentsCustomers])

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Dashboard</h1>
      {!stats ? <div>Loading…</div> : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {user.role === 'super_admin' && (<>
            <Stat label="Employees" value={stats.employees} />
            <Stat label="Agents" value={stats.agents} />
            <Stat label="Customers" value={stats.customers} />
            <Stat label="Total Premium" value={stats.total_premium} />
            <Stat label="Total Commission" value={stats.total_commission} />
          </>)}
          {user.role === 'employee' && (<>
            <Stat label="My Agents" value={stats.my_agents} />
            <Stat label="My Customers" value={stats.my_customers} />
          </>)}
          {user.role === 'agent' && (<>
            <Stat label="My Customers" value={stats.my_customers} />
          </>)}
        </div>
      )}

      {user.role === 'employee' && myAgents.length > 0 && (
        <div className="space-y-2">
          <h2 className="text-xl font-semibold">My Agents</h2>
          <Table
            columns={[
              { key: 'name', title: 'Name' },
              { key: 'phone_no', title: 'Phone' },
              { key: 'customers_count', title: '# Customers', render: (_v, row) => customersPerAgent[row.id] || 0 },
            ]}
            data={myAgents}
          />
        </div>
      )}
    </div>
  )
}
