import React, { useEffect, useState, useMemo } from 'react'
import { http } from '../../utils/api'
import Table from '../../components/Table'
export default function AgentsCustomers() {
  const [list, setList] = useState([])
  const [agents, setAgents] = useState([])
  useEffect(()=>{ (async()=>{ setList(await http('/employee/agents/customers')); setAgents(await http('/employee/agents')) })() }, [])
  const agentById = useMemo(() => Object.fromEntries(agents.map(a=>[a.id,a])), [agents])
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Agents' Customers</h1>
      <Table columns={[
        { key:'name', title:'Name' },
        { key:'status', title:'Status', render:(v)=>{ const cls = v==='Closed'?'badge-green': v==='Denied'?'badge-red':'badge-yellow'; return <span className={cls}>{v}</span> } },
        { key:'agent_id', title:'Agent (Email)', render:(v)=> agentById[v]?.email || '—' }
      ]} data={list} />
    </div>
  )
}
