CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  role TEXT NOT NULL CHECK (role IN ('super_admin','employee','agent')),
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone_no TEXT,
  password_hash TEXT NOT NULL,
  pan_number TEXT,
  aadhaar_number TEXT,
  bank_name TEXT,
  bank_ifsc TEXT,
  bank_account_no TEXT,
  edu_10 TEXT,
  edu_12 TEXT,
  edu_degree TEXT,
  onboarding_employee_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  salary_monthly NUMERIC(12,2),
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS customers (
  id SERIAL PRIMARY KEY,
  agent_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  age INTEGER,
  number_of_children INTEGER,
  parents TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','Closed','Denied')),
  aadhaar_number TEXT,
  pan_number TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS targets (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  month TEXT NOT NULL,
  target_policies INTEGER NOT NULL DEFAULT 0,
  target_premium NUMERIC(14,2) NOT NULL DEFAULT 0,
  UNIQUE (user_id, month)
);

CREATE TABLE IF NOT EXISTS finance_entries (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  month TEXT NOT NULL,
  net_premium NUMERIC(14,2) NOT NULL DEFAULT 0,
  net_commission NUMERIC(14,2) NOT NULL DEFAULT 0,
  UNIQUE (user_id, month)
);

CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_customers_agent ON customers(agent_id);
CREATE INDEX IF NOT EXISTS idx_targets_user ON targets(user_id);
CREATE INDEX IF NOT EXISTS idx_finance_user ON finance_entries(user_id);


ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS email TEXT,
  ADD COLUMN IF NOT EXISTS phone_no TEXT;

-- (Optional) basic index helpers if you plan to search/filter
CREATE INDEX IF NOT EXISTS idx_customers_email ON customers ((lower(coalesce(email, ''))));
CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers (phone_no);