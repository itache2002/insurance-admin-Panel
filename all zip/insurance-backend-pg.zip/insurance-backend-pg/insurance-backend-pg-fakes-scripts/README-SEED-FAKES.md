# Fake Data Seeder

This adds realistic test data across **employees**, **agents**, **customers**, **targets**, and **finance_entries**.

## How to use
1) Ensure your DB is migrated:
```
npm run migrate
```

2) Run the fake seeder:
```
node -r dotenv/config scripts/seed-fakes.js
```
_or add a script to your package.json:_
```json
{
  "scripts": {
    "seed:fakes": "node -r dotenv/config scripts/seed-fakes.js"
  }
}
```

## Accounts created
- Super Admin: `admin@example.com` / `Admin@123`
- Employees: `emp1@demo.local`, `emp2@demo.local`, `emp3@demo.local` (password: `Pass@123`)
- Agents: `agent1@demo.local` ... `agent6@demo.local` (password: `Pass@123`)

## What gets inserted
- 3 Employees
- 6 Agents (2 per employee)
- 10 Customers per Agent (60 total), with mixed statuses
- Monthly Targets & Finance for last 3 months for all employees & agents
