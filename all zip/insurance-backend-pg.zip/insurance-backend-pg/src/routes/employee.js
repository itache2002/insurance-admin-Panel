import express from 'express';
import { pool, sql } from '../db.js';
import { requireAuth, requireRole, Roles, hashPassword } from '../utils/auth.js';

const router = express.Router();
router.use(requireAuth, requireRole(Roles.EMPLOYEE, Roles.SUPER_ADMIN));

/** Employee creates Agent */
router.post('/agents', async (req, res, next) => {
  try {
    const { name, email, phone_no, password, pan_number, aadhaar_number, bank, education } = req.body;
    const hash = await hashPassword(password || 'ChangeMe123!');
    const user = await pool.one(sql`INSERT INTO users (role, name, email, phone_no, password_hash, pan_number, aadhaar_number,
      bank_name, bank_ifsc, bank_account_no, edu_10, edu_12, edu_degree, onboarding_employee_id)
      VALUES ('agent', ${name}, ${email}, ${phone_no}, ${hash}, ${pan_number}, ${aadhaar_number},
              ${bank?.name || null}, ${bank?.ifsc || null}, ${bank?.account_no || null},
              ${education?.x10 || null}, ${education?.x12 || null}, ${education?.degree || null},
              ${req.user.id})
      RETURNING id, role, name, email, phone_no`);
    res.json(user);
  } catch (e) { next(e); }
});

/** Employee profile */
router.get('/me', async (req, res, next) => {
  try {
    const me = await pool.one(sql`SELECT id, name, email, phone_no, salary_monthly FROM users WHERE id = ${req.user.id}`);
    res.json(me);
  } catch (e) { next(e); }
});

/** View targets of an agent (that this employee onboarded) */
router.get('/agents/:agentId/targets', async (req, res, next) => {
  try {
    const { agentId } = req.params;
    const rows = await pool.any(sql`SELECT * FROM targets WHERE user_id = ${agentId} ORDER BY month DESC`);
    res.json(rows);
  } catch (e) { next(e); }
});

/** List all agents onboarded by this employee */
router.get('/agents', async (req, res, next) => {
  try {
    const rows = await pool.any(sql`SELECT id, name, email, phone_no FROM users WHERE role='agent' AND onboarding_employee_id = ${req.user.id} ORDER BY id DESC`);
    res.json(rows);
  } catch (e) { next(e); }
});

/** All customers created by those agents */
router.get('/agents/customers', async (req, res, next) => {
  try {
    const rows = await pool.any(sql`SELECT c.* FROM customers c JOIN users a ON a.id = c.agent_id WHERE a.onboarding_employee_id = ${req.user.id} ORDER BY c.id DESC`);
    res.json(rows);
  } catch (e) { next(e); }
});

export default router;
