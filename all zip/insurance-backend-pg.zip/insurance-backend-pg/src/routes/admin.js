import express from 'express';
import { pool, sql } from '../db.js';
import { requireAuth, requireRole, Roles, hashPassword } from '../utils/auth.js';

const router = express.Router();

router.use(requireAuth, requireRole(Roles.SUPER_ADMIN));

/** Create Employee or Super Admin */
router.post('/users', async (req, res, next) => {
  try {
    const { role, name, email, phone_no, password, pan_number, aadhaar_number, bank, education } = req.body;
    if (!['employee','super_admin'].includes(role)) return res.status(400).json({ error: 'Invalid role' });
    const hash = await hashPassword(password || 'ChangeMe123!');
    const user = await pool.one(sql`INSERT INTO users (role, name, email, phone_no, password_hash, pan_number, aadhaar_number,
      bank_name, bank_ifsc, bank_account_no, edu_10, edu_12, edu_degree)
      VALUES (${role}, ${name}, ${email}, ${phone_no}, ${hash}, ${pan_number}, ${aadhaar_number},
              ${bank?.name || null}, ${bank?.ifsc || null}, ${bank?.account_no || null},
              ${education?.x10 || null}, ${education?.x12 || null}, ${education?.degree || null})
      RETURNING id, role, name, email, phone_no`);
    res.json(user);
  } catch (e) { next(e); }
});

/** Create Agent (optionally assign onboarding_employee_id) */
router.post('/agents', async (req, res, next) => {
  try {
    const { name, email, phone_no, password, pan_number, aadhaar_number, bank, education, onboarding_employee_id, salary_monthly } = req.body;
    const hash = await hashPassword(password || 'ChangeMe123!');
    const user = await pool.one(sql`INSERT INTO users (role, name, email, phone_no, password_hash, pan_number, aadhaar_number,
      bank_name, bank_ifsc, bank_account_no, edu_10, edu_12, edu_degree, onboarding_employee_id, salary_monthly)
      VALUES ('agent', ${name}, ${email}, ${phone_no}, ${hash}, ${pan_number}, ${aadhaar_number},
              ${bank?.name || null}, ${bank?.ifsc || null}, ${bank?.account_no || null},
              ${education?.x10 || null}, ${education?.x12 || null}, ${education?.degree || null},
              ${onboarding_employee_id || null}, ${salary_monthly || null})
      RETURNING id, role, name, email, phone_no`);
    res.json(user);
  } catch (e) { next(e); }
});

/** List Employees, Agents, Customers */

router.get('/overview', authRequired, allowRoles(['super_admin']), async (_req, res, next) => {
  try {
    const [emp, ag, cu] = await Promise.all([
      pool.query(`SELECT id, name, email, phone_no FROM users WHERE role IN ('employee','super_admin') ORDER BY id DESC`),
      pool.query(`SELECT id, name, email, phone_no, onboarding_employee_id FROM agents ORDER BY id DESC`),
      pool.query(`SELECT id, name, email, phone_no, status, agent_id FROM customers ORDER BY id DESC`)
    ])

    res.json({
      employees: emp.rows,
      agents: ag.rows,
      customers: cu.rows
    })
  } catch (err) {
    next(err)
  }
})

/** Set salary for any user (employee or agent) */
router.post('/salary/:userId', async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { salary_monthly } = req.body;
    const row = await pool.one(sql`UPDATE users SET salary_monthly = ${salary_monthly} WHERE id = ${userId} RETURNING id, name, role, salary_monthly`);
    res.json(row);
  } catch (e) { next(e); }
});

export default router;
