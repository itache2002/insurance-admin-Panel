import express from 'express';
import { pool, sql } from '../db.js';
import { hashPassword, comparePassword, signToken } from '../utils/auth.js';

const router = express.Router();

router.post('/register-initial-superadmin', async (req, res, next) => {
  try {
    const { name, email, password } = req.body;
    const exists = await pool.maybeOne(sql`SELECT id FROM users WHERE email = ${email}`);
    if (exists) return res.status(400).json({ error: 'Email already registered' });
    const hash = await hashPassword(password);
    const user = await pool.one(sql`INSERT INTO users (name, email, role, password_hash) 
      VALUES (${name}, ${email}, 'super_admin', ${hash}) RETURNING id, name, email, role`);
    const token = signToken({ id: user.id, role: user.role, email: user.email, name: user.name });
    res.json({ user, token });
  } catch (e) { next(e); }
});

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await pool.maybeOne(sql`SELECT id, name, email, role, password_hash FROM users WHERE email = ${email}`);
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    const ok = await comparePassword(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
    const token = signToken({ id: user.id, role: user.role, email: user.email, name: user.name });
    res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role }, token });
  } catch (e) { next(e); }
});

export default router;
