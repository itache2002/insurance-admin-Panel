import pg from 'pg';

/**
 * Tiny SQL tag:
 *   const q = sql`SELECT * FROM users WHERE id = ${id} AND email = ${email}`
 * Produces: { text: 'SELECT ... $1 ... $2', values: [id, email] }
 */
export function sql(strings, ...values) {
  const text = strings.reduce((acc, s, i) => acc + s + (i < values.length ? `$${i + 1}` : ''), '');
  return { text, values };
}

const poolRaw = new pg.Pool({
  host: process.env.PGHOST,
  port: Number(process.env.PGPORT) || 5432,
  user: process.env.PGUSER,
  password: process.env.PGPASSWORD,
  database: process.env.PGDATABASE,
  ssl: process.env.PGSSL === 'require' ? { rejectUnauthorized: false } : undefined
});

async function query(q) {
  if (typeof q === 'string') return poolRaw.query(q);
  return poolRaw.query(q.text, q.values);
}

async function one(q) {
  const res = await query(q);
  if (res.rows.length === 0) throw Object.assign(new Error('No rows'), { status: 404 });
  return res.rows[0];
}

async function maybeOne(q) {
  const res = await query(q);
  return res.rows[0] || null;
}

async function any(q) {
  const res = await query(q);
  return res.rows;
}

/**
 * Export a pool-like facade so existing code can call:
 *   pool.one(sql`...`), pool.any(sql`...`), pool.maybeOne(sql`...`), pool.query(...)
 */
export const pool = { query, one, any, maybeOne };
