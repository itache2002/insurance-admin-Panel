# Insurance Backend (Node.js + Express + PostgreSQL) — PG version

This build **does not use Slonik**. It uses `pg` with a tiny `sql` tag and helper methods:
- `pool.query(q)`
- `pool.one(q)`
- `pool.any(q)`
- `pool.maybeOne(q)`
where `q` can be the object returned by the `sql` template tag.

## Quick Start
```bash
npm i
cp .env.example .env
# set your PG creds
npm run migrate
npm run seed
npm run dev
```

Auth:
- POST `/api/auth/register-initial-superadmin` { name, email, password }
- POST `/api/auth/login` { email, password } → `{ token }`

Use `Authorization: Bearer <token>` for protected routes.
