import React from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { getUser, clearAuth } from '../utils/api'

const NavLink = ({ to, children }) => {
  const loc = useLocation()
  const active = loc.pathname.startsWith(to)
  return (
    <Link to={to} className={`block px-3 py-2 rounded-lg ${active ? 'bg-brand-100 text-brand-800' : 'hover:bg-gray-100'}`}>
      {children}
    </Link>
  )
}

export default function Layout({ children }) {
  const user = getUser()
  const navigate = useNavigate()
  return (
    <div className="min-h-screen grid grid-cols-[260px_1fr]">
      <aside className="border-r border-gray-200 bg-white p-4">
        <div className="flex items-center gap-2 mb-6">
          <div className="h-10 w-10 rounded-xl bg-brand-600 text-white grid place-items-center font-bold">IN</div>
          <div>
            <div className="font-semibold">Insurance Admin</div>
            <div className="text-xs text-gray-500">{user?.role}</div>
          </div>
        </div>

        <nav className="space-y-1">
          <NavLink to="/dashboard">Dashboard</NavLink>
          {(user?.role === 'super_admin') && (<>
            <div className="mt-3 text-xs uppercase text-gray-400 px-2">Super Admin</div>
            <NavLink to="/super/overview">Overview</NavLink>
            <NavLink to="/super/users">Employees & Admins</NavLink>
            <NavLink to="/super/agents">Agents</NavLink>
            <NavLink to="/super/targets">Targets</NavLink>
            <NavLink to="/super/finance">Finance</NavLink>
            <NavLink to="/customers">Customers</NavLink>
          </>)}

          {(user?.role === 'employee') && (<>
            <div className="mt-3 text-xs uppercase text-gray-400 px-2">Employee</div>
            <NavLink to="/employee/profile">My Profile</NavLink>
            <NavLink to="/employee/agents">My Agents</NavLink>
            <NavLink to="/employee/agents-customers">Agents' Customers</NavLink>
            <NavLink to="/employee/analytics">Analytics</NavLink>
          </>)}

          {(user?.role === 'agent') && (<>
            <div className="mt-3 text-xs uppercase text-gray-400 px-2">Agent</div>
            <NavLink to="/agent/profile">My Profile</NavLink>
            <NavLink to="/agent/customers">My Customers</NavLink>
            <NavLink to="/agent/customers/new">New Customer</NavLink>
            <NavLink to="/agent/analytics">Analytics</NavLink>
          </>)}
        </nav>

        <div className="mt-6">
          <button className="btn-outline w-full" onClick={()=>{ clearAuth(); navigate('/login'); }}>Logout</button>
        </div>
      </aside>
      <main className="p-6">
        {children}
      </main>
    </div>
  )
}
