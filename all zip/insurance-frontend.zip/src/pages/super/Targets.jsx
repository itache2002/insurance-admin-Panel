import React, { useEffect, useState } from 'react'
import { http } from '../../utils/api'
import Table from '../../components/Table'

export default function SuperTargets() {
  const [list, setList] = useState([])
  const [form, setForm] = useState({ user_id:'', month:'2025-08', target_policies:'', target_premium:'' })

  async function load() {
    // no global list endpoint; show per user lookup after upserts.
  }
  useEffect(()=>{ load() }, [])

  async function submit(e) {
    e.preventDefault()
    await http('/targets', { method:'POST', body: form })
    alert('Target saved')
  }

  async function searchUserTargets() {
    if (!form.user_id) return
    const rows = await http(`/targets/user/${form.user_id}`)
    setList(rows)
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Set Targets</h1>
      <div className="card p-4">
        <form onSubmit={submit} className="grid sm:grid-cols-4 gap-4">
          <div><label className="label">User ID</label><input className="input" value={form.user_id} onChange={e=>setForm({...form, user_id:e.target.value})}/></div>
          <div><label className="label">Month (YYYY-MM)</label><input className="input" value={form.month} onChange={e=>setForm({...form, month:e.target.value})}/></div>
          <div><label className="label">Target Policies</label><input className="input" value={form.target_policies} onChange={e=>setForm({...form, target_policies:e.target.value})}/></div>
          <div><label className="label">Target Premium</label><input className="input" value={form.target_premium} onChange={e=>setForm({...form, target_premium:e.target.value})}/></div>
          <div className="sm:col-span-4 flex gap-2">
            <button className="btn">Save / Update</button>
            <button type="button" className="btn-outline" onClick={searchUserTargets}>View User Targets</button>
          </div>
        </form>
      </div>

      <Table columns={[
        { key:'month', title:'Month' },
        { key:'target_policies', title:'Policies' },
        { key:'target_premium', title:'Premium' },
      ]} data={list} keyField="month" />
    </div>
  )
}
