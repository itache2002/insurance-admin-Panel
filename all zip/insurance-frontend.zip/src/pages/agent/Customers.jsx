import React, { useEffect, useState } from 'react'
import { http } from '../../utils/api'
import Table from '../../components/Table'

export default function AgentCustomers() {
  const [list, setList] = useState([])
  const [statusUpd, setStatusUpd] = useState({ id:'', status:'pending' })

  async function load(){ setList(await http('/customers/mine')) }
  useEffect(()=>{ load() }, [])

  async function changeStatus(e) {
    e.preventDefault()
    await http(`/customers/${statusUpd.id}/status`, { method:'PATCH', body:{ status: statusUpd.status } })
    setStatusUpd({ id:'', status:'pending' })
    await load()
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">My Customers</h1>
      <Table columns={[
        { key:'id', title:'ID' },
        { key:'name', title:'Name' },
        { key:'status', title:'Status' },
      ]} data={list} />

      <div className="card p-4">
        <h2 className="font-semibold mb-2">Change Status</h2>
        <form onSubmit={changeStatus} className="grid sm:grid-cols-3 gap-4">
          <div><label className="label">Customer ID</label><input className="input" value={statusUpd.id} onChange={e=>setStatusUpd({...statusUpd, id:e.target.value})}/></div>
          <div>
            <label className="label">Status</label>
            <select className="input" value={statusUpd.status} onChange={e=>setStatusUpd({...statusUpd, status:e.target.value})}>
              <option>pending</option>
              <option>Closed</option>
              <option>Denied</option>
            </select>
          </div>
          <div className="sm:col-span-3"><button className="btn">Update</button></div>
        </form>
      </div>
    </div>
  )
}
