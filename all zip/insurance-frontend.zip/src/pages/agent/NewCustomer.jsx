import React, { useState } from 'react'
import { http } from '../../utils/api'

export default function NewCustomer() {
  const [form, setForm] = useState({
    name:'', age:'', number_of_children:'', parents:'', status:'pending', aadhaar_number:'', pan_number:''
  })

  async function submit(e) {
    e.preventDefault()
    await http('/customers', { method:'POST', body: form })
    setForm({ name:'', age:'', number_of_children:'', parents:'', status:'pending', aadhaar_number:'', pan_number:'' })
    alert('Customer created')
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">New Customer</h1>
      <div className="card p-4">
        <form onSubmit={submit} className="grid sm:grid-cols-2 gap-4">
          <div><label className="label">Name</label><input className="input" value={form.name} onChange={e=>setForm({...form, name:e.target.value})}/></div>
          <div><label className="label">Age</label><input className="input" value={form.age} onChange={e=>setForm({...form, age:e.target.value})}/></div>
          <div><label className="label">Children</label><input className="input" value={form.number_of_children} onChange={e=>setForm({...form, number_of_children:e.target.value})}/></div>
          <div><label className="label">Parents</label><input className="input" value={form.parents} onChange={e=>setForm({...form, parents:e.target.value})}/></div>
          <div>
            <label className="label">Status</label>
            <select className="input" value={form.status} onChange={e=>setForm({...form, status:e.target.value})}>
              <option>pending</option>
              <option>Closed</option>
              <option>Denied</option>
            </select>
          </div>
          <div><label className="label">Aadhaar</label><input className="input" value={form.aadhaar_number} onChange={e=>setForm({...form, aadhaar_number:e.target.value})}/></div>
          <div><label className="label">PAN</label><input className="input" value={form.pan_number} onChange={e=>setForm({...form, pan_number:e.target.value})}/></div>
          <div className="sm:col-span-2"><button className="btn">Create</button></div>
        </form>
      </div>
    </div>
  )
}
