import React from 'react'
import Dashboard from '../Dashboard.jsx'
export default function AgentAnalytics(){ return <Dashboard /> }
