import React, { useEffect, useState } from 'react'
import { http } from '../utils/api'
import Table from '../components/Table'

export default function Customers() {
  const [list, setList] = useState([])

  useEffect(()=>{
    (async () => setList(await http('/customers')))()
  }, [])

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">All Customers</h1>
      <Table columns={[
        { key:'id', title:'ID' },
        { key:'name', title:'Name' },
        { key:'status', title:'Status' },
        { key:'agent_id', title:'Agent' },
      ]} data={list} />
    </div>
  )
}
