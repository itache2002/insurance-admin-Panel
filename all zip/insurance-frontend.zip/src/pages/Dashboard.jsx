import React, { useEffect, useState } from 'react'
import { http, getUser } from '../utils/api'

function Stat({ label, value }) {
  return (
    <div className="card p-4">
      <div className="text-sm text-gray-500">{label}</div>
      <div className="text-2xl font-semibold">{value}</div>
    </div>
  )
}

export default function Dashboard() {
  const [stats, setStats] = useState(null)
  const user = getUser()

  useEffect(() => {
    (async () => {
      const data = await http('/analytics/basic')
      setStats(data.stats)
    })()
  }, [])

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Dashboard</h1>
      {!stats ? <div>Loading...</div> : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {user.role === 'super_admin' && (<>
            <Stat label="Employees" value={stats.employees} />
            <Stat label="Agents" value={stats.agents} />
            <Stat label="Customers" value={stats.customers} />
            <Stat label="Total Premium" value={stats.total_premium} />
            <Stat label="Total Commission" value={stats.total_commission} />
          </>)}
          {user.role === 'employee' && (<>
            <Stat label="My Agents" value={stats.my_agents} />
            <Stat label="My Customers" value={stats.my_customers} />
            <Stat label="Total Premium" value={stats.total_premium} />
            <Stat label="Total Commission" value={stats.total_commission} />
          </>)}
          {user.role === 'agent' && (<>
            <Stat label="My Customers" value={stats.my_customers} />
            <Stat label="My Premium" value={stats.my_premium} />
            <Stat label="My Commission" value={stats.my_commission} />
          </>)}
        </div>
      )}
    </div>
  )
}
