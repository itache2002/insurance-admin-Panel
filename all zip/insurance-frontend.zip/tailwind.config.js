/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eefcf7',
          100: '#d6f6ea',
          200: '#b1ead7',
          300: '#80d6be',
          400: '#4bbd9f',
          500: '#27a887',
          600: '#1b8a71',
          700: '#196e5c',
          800: '#17584b',
          900: '#13483f'
        }
      }
    }
  },
  plugins: []
}
