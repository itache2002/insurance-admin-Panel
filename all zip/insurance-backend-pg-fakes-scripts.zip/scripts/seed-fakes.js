import { pool, sql } from '../src/db.js';
import { hashPassword } from '../src/utils/auth.js';

/**
 * Run with:
 *   npm run migrate
 *   node -r dotenv/config scripts/seed-fakes.js
 * or add to package.json:
 *   "seed:fakes": "node -r dotenv/config scripts/seed-fakes.js"
 */

function randInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function pick(arr) { return arr[randInt(0, arr.length - 1)]; }

async function ensureSuperAdmin() {
  const email = 'admin@example.com';
  const exists = await pool.maybeOne(sql`SELECT id FROM users WHERE email=${email}`);
  if (!exists) {
    const pass = await hashPassword('Admin@123');
    await pool.query(sql`INSERT INTO users (role,name,email,password_hash) VALUES ('super_admin','Root Admin',${email},${pass})`);
    console.log('Seeded super admin:', email);
  } else {
    console.log('Super admin already exists');
  }
}

async function insertEmployee(i) {
  const name = `Employee ${i}`;
  const email = `emp${i}@demo.local`;
  const exists = await pool.maybeOne(sql`SELECT id FROM users WHERE email=${email}`);
  if (exists) return exists;
  const pass = await hashPassword('Pass@123');
  const row = await pool.one(sql`
    INSERT INTO users
      (role, name, email, phone_no, password_hash, pan_number, aadhaar_number,
       bank_name, bank_ifsc, bank_account_no, edu_10, edu_12, edu_degree, salary_monthly)
    VALUES
      ('employee', ${name}, ${email}, ${'90000000' + i}, ${pass}, ${'ABCDE' + i + '1F'},
       ${'12341234123' + i}, ${'Demo Bank'}, ${'DEMO000' + i}, ${'1234567890' + i},
       ${'Yes'}, ${'Yes'}, ${'B.Com'}, ${35000 + i*2000})
    RETURNING id, name, email`);
  return row;
}

async function insertAgent(i, onboardingEmployeeId) {
  const name = `Agent ${i}`;
  const email = `agent${i}@demo.local`;
  const exists = await pool.maybeOne(sql`SELECT id FROM users WHERE email=${email}`);
  if (exists) return exists;
  const pass = await hashPassword('Pass@123');
  const row = await pool.one(sql`
    INSERT INTO users
      (role, name, email, phone_no, password_hash, pan_number, aadhaar_number,
       bank_name, bank_ifsc, bank_account_no, edu_10, edu_12, edu_degree,
       onboarding_employee_id, salary_monthly)
    VALUES
      ('agent', ${name}, ${email}, ${'98880000' + i}, ${pass}, ${'PQRSR' + i + '2Z'},
       ${'9988776655' + i}, ${'Demo Bank'}, ${'DEMO999' + i}, ${'9876543210' + i},
       ${'Yes'}, ${'Yes'}, ${'BA'}, ${onboardingEmployeeId}, ${22000 + i*1500})
    RETURNING id, name, email`);
  return row;
}

async function insertCustomer(i, agentId) {
  const statuses = ['pending', 'Closed', 'Denied'];
  const row = await pool.one(sql`
    INSERT INTO customers (agent_id, name, age, number_of_children, parents, status, aadhaar_number, pan_number)
    VALUES (${agentId}, ${'Customer ' + i}, ${randInt(22,60)}, ${randInt(0,3)},
            ${'Mother,Father'}, ${pick(statuses)}, ${'999988887777' + i}, ${'AAAAA' + (1000 + i)})
    RETURNING id`);
  return row;
}

async function upsertTarget(userId, month) {
  const targetPolicies = randInt(5, 25);
  const targetPremium = randInt(100000, 500000);
  await pool.query(sql`
    INSERT INTO targets (user_id, month, target_policies, target_premium)
    VALUES (${userId}, ${month}, ${targetPolicies}, ${targetPremium})
    ON CONFLICT (user_id, month) DO UPDATE SET target_policies = EXCLUDED.target_policies, target_premium = EXCLUDED.target_premium
  `);
}

async function upsertFinance(userId, month) {
  const netPremium = randInt(50000, 300000);
  const netCommission = Math.round(netPremium * (randInt(5,15)/100));
  await pool.query(sql`
    INSERT INTO finance_entries (user_id, month, net_premium, net_commission)
    VALUES (${userId}, ${month}, ${netPremium}, ${netCommission})
    ON CONFLICT (user_id, month) DO UPDATE SET net_premium = EXCLUDED.net_premium, net_commission = EXCLUDED.net_commission
  `);
}

async function run() {
  console.log('Seeding fake data...');
  await ensureSuperAdmin();

  // 1) Employees
  const employees = [];
  for (let i=1; i<=3; i++) {
    const emp = await insertEmployee(i);
    employees.push(emp);
  }
  console.log('Employees:', employees.map(e=>e.email).join(', '));

  // 2) Agents (2 per employee = 6)
  const agents = [];
  let agentIndex = 1;
  for (const emp of employees) {
    for (let k=0; k<2; k++) {
      const ag = await insertAgent(agentIndex, emp.id);
      agents.push(ag);
      agentIndex++;
    }
  }
  console.log('Agents:', agents.map(a=>a.email).join(', '));

  // 3) Customers (10 per agent)
  for (const ag of agents) {
    for (let j=1; j<=10; j++) {
      await insertCustomer(((ag.id*100)+j), ag.id);
    }
  }
  console.log('Customers: inserted', agents.length * 10);

  // 4) Targets + Finance for the last 3 months for all employees & agents
  const months = ['2025-06','2025-07','2025-08'];
  for (const m of months) {
    for (const emp of employees) {
      await upsertTarget(emp.id, m);
      await upsertFinance(emp.id, m);
    }
    for (const ag of agents) {
      await upsertTarget(ag.id, m);
      await upsertFinance(ag.id, m);
    }
  }
  console.log('Targets & Finance upserted for months:', months.join(', '));

  console.log('\nLogin accounts created for quick testing:');
  console.log('  Super Admin: admin@example.com / Admin@123');
  console.log('  Employees:   emp1@demo.local, emp2@demo.local, emp3@demo.local    (password: Pass@123)');
  console.log('  Agents:      agent1@demo.local ... agent6@demo.local              (password: Pass@123)');
  console.log('\nDone.');
  process.exit(0);
}

run().catch(err => { console.error(err); process.exit(1); });
