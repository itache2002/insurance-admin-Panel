import React, { useState } from 'react'
import Card from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import DataTable from '../../components/data/DataTable'
import { api } from '../../lib/api'
export default function EmployeeAgents(){
  const [rows,setRows]=useState([])
  return <Card title="My Agents" actions={<Button variant="outline" onClick={async()=>setRows(await api.employee.agents())}>Refresh</Button>}>
    <DataTable columns={[{key:'id',label:'ID'},{key:'name',label:'Name'},{key:'email',label:'Email'},{key:'phone_no',label:'Phone'}]} rows={rows}/>
  </Card>
}
