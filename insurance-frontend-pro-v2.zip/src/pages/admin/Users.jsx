import React, { useEffect, useState } from 'react'
import Card from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import { Field } from '../../components/ui/Field'
import { Input, Select } from '../../components/ui/Input'
import DataTable from '../../components/data/DataTable'
import { api } from '../../lib/api'

export default function AdminUsers(){
  const [form,setForm]=useState({role:'agent',name:'',email:'',phone_no:'',employee_supervisor_id:''})
  const [users,setUsers]=useState([]); const [temp,setTemp]=useState(null)
  async function createUser(){ const res = await api.admin.createUser(form); setTemp(res.temp_password); alert('Temp password: '+res.temp_password+'\nShare this only once.') }
  async function loadUsers(){ setUsers(await api.admin.users()) }
  useEffect(()=>{ loadUsers() }, [])
  return <div className="grid gap-6 md:grid-cols-2">
    <Card title="Create User" subtitle="Admin, Employee, Agent" actions={<Button onClick={createUser}>Create</Button>}>
      <div className="flex flex-wrap gap-3">
        <Field label="Role"><Select value={form.role} onChange={e=>setForm({...form,role:e.target.value})}><option value="admin">admin</option><option value="employee">employee</option><option value="agent">agent</option></Select></Field>
        <Field label="Name"><Input onChange={e=>setForm({...form,name:e.target.value})}/></Field>
        <Field label="Email"><Input onChange={e=>setForm({...form,email:e.target.value})}/></Field>
        <Field label="Phone"><Input onChange={e=>setForm({...form,phone_no:e.target.value})}/></Field>
        {form.role==='agent' && <Field label="Supervisor (Employee ID)"><Input onChange={e=>setForm({...form,employee_supervisor_id:e.target.value})}/></Field>}
      </div>
      <div className="text-xs text-yellow-400 mt-3">⚠️ New users must change password on first login.</div>
      {temp && <div className="tag mt-3">Temp password: <b className="ml-1">{temp}</b></div>}
    </Card>
    <Card title="All Users" subtitle="Search, sort, paginate" actions={<Button variant="outline" onClick={loadUsers}>Refresh</Button>}>
      <DataTable columns={[{key:'id',label:'ID'},{key:'role',label:'Role'},{key:'name',label:'Name'},{key:'email',label:'Email'}]} rows={users}/>
    </Card>
  </div>
}
