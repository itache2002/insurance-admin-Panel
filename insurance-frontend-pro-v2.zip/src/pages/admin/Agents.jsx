import React, { useEffect, useState } from 'react'
import Card from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import { Field } from '../../components/ui/Field'
import { Input } from '../../components/ui/Input'
import DataTable from '../../components/data/DataTable'
import { api } from '../../lib/api'

export default function AdminAgents(){
  const [agents,setAgents]=useState([]); const [aid,setAid]=useState('')
  const [comp,setComp]=useState({base_salary:'',commission_rate:'0.05'}); const [empId,setEmpId]=useState('')
  async function load(){ setAgents(await api.admin.agents()) }
  useEffect(()=>{ load() }, [])
  return <div className="grid gap-6">
    <Card title="Agents" actions={<Button variant="outline" onClick={load}>Refresh</Button>}>
      <DataTable columns={[{key:'agent_id',label:'ID'},{key:'agent_name',label:'Name'},{key:'email',label:'Email'},{key:'phone_no',label:'Phone'},{key:'customer_count',label:'Customers'}]} rows={agents}/>
    </Card>
    <div className="grid gap-6 md:grid-cols-2">
      <Card title="Compensation">
        <div className="flex flex-wrap gap-3">
          <Field label="Agent ID"><Input value={aid} onChange={e=>setAid(e.target.value)}/></Field>
          <Field label="Base Salary"><Input value={comp.base_salary} onChange={e=>setComp({...comp,base_salary:e.target.value})}/></Field>
          <Field label="Commission Rate"><Input value={comp.commission_rate} onChange={e=>setComp({...comp,commission_rate:e.target.value})}/></Field>
          <Button onClick={()=>api.admin.setAgentComp(aid,Number(comp.base_salary),Number(comp.commission_rate))}>Save</Button>
        </div>
      </Card>
      <Card title="Supervisor">
        <div className="flex flex-wrap gap-3">
          <Field label="Agent ID"><Input value={aid} onChange={e=>setAid(e.target.value)}/></Field>
          <Field label="Supervisor Employee ID"><Input value={empId} onChange={e=>setEmpId(e.target.value)}/></Field>
          <Button onClick={()=>api.admin.setAgentSupervisor(aid, empId)}>Set Supervisor</Button>
        </div>
      </Card>
    </div>
  </div>
}
