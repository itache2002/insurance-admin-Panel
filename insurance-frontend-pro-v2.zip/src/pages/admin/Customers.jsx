import React, { useEffect, useState } from 'react'
import Card from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import { Field } from '../../components/ui/Field'
import { Input, Select } from '../../components/ui/Input'
import DataTable from '../../components/data/DataTable'
import { api } from '../../lib/api'

export default function AdminCustomers(){
  const [rows,setRows]=useState([]); const [cid,setCid]=useState(''); const [status,setStatus]=useState('Pending')
  async function load(){ setRows(await api.customers.list()) }
  useEffect(()=>{ load() }, [])
  return <div className="grid gap-6 md:grid-cols-2">
    <Card title="All Customers" actions={<Button variant="outline" onClick={load}>Refresh</Button>}>
      <DataTable columns={[{key:'id',label:'ID'},{key:'name',label:'Name'},{key:'email',label:'Email'},{key:'phone_no',label:'Phone'},{key:'status',label:'Status'}]} rows={rows}/>
    </Card>
    <Card title="Update Customer Status">
      <div className="flex flex-wrap gap-3">
        <Field label="Customer ID"><Input value={cid} onChange={e=>setCid(e.target.value)}/></Field>
        <Field label="Status"><Select value={status} onChange={e=>setStatus(e.target.value)}><option>Pending</option><option>Closed</option><option>Denied</option></Select></Field>
        <Button onClick={()=>api.admin.setCustomerStatus(cid,status)}>Update</Button>
      </div>
    </Card>
  </div>
}
