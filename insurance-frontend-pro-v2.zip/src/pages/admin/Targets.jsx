import React, { useState } from 'react'
import Card from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import { Field } from '../../components/ui/Field'
import { Input } from '../../components/ui/Input'
import { api } from '../../lib/api'

export default function AdminTargets(){
  const [agent,setAgent]=useState(''); const [month,setMonth]=useState('2025-08-01'); const [target,setTarget]=useState('100000'); const [delta,setDelta]=useState('5000'); const [note,setNote]=useState('')
  return <div className="grid gap-6 md:grid-cols-2">
    <Card title="Set Agent Monthly Target">
      <div className="flex flex-wrap gap-3">
        <Field label="Agent ID"><Input value={agent} onChange={e=>setAgent(e.target.value)}/></Field>
        <Field label="Month (YYYY-MM-DD)"><Input value={month} onChange={e=>setMonth(e.target.value)}/></Field>
        <Field label="Target Value"><Input value={target} onChange={e=>setTarget(e.target.value)}/></Field>
        <Button onClick={()=>api.admin.setAgentTarget(agent, month, Number(target))}>Save Target</Button>
      </div>
    </Card>
    <Card title="Add Progress">
      <div className="flex flex-wrap gap-3">
        <Field label="Agent ID"><Input value={agent} onChange={e=>setAgent(e.target.value)}/></Field>
        <Field label="Month (YYYY-MM-DD)"><Input value={month} onChange={e=>setMonth(e.target.value)}/></Field>
        <Field label="Delta"><Input value={delta} onChange={e=>setDelta(e.target.value)}/></Field>
        <Field label="Note"><Input value={note} onChange={e=>setNote(e.target.value)}/></Field>
        <Button onClick={()=>api.admin.addTargetProgress(agent, month, Number(delta), note)}>Add Progress</Button>
      </div>
    </Card>
  </div>
}
