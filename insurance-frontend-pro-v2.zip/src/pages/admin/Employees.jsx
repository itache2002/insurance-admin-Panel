import React, { useEffect, useState } from 'react'
import Card from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import { Field } from '../../components/ui/Field'
import { Input } from '../../components/ui/Input'
import DataTable from '../../components/data/DataTable'
import { api } from '../../lib/api'

export default function AdminEmployees(){
  const [rows,setRows]=useState([]); const [id,setId]=useState(''); const [salary,setSalary]=useState('')
  async function load(){ setRows(await api.admin.employees()) }
  useEffect(()=>{ load() }, [])
  return <div className="grid gap-6 md:grid-cols-2">
    <Card title="Employees" actions={<Button variant="outline" onClick={load}>Refresh</Button>}>
      <DataTable columns={[{key:'id',label:'ID'},{key:'name',label:'Name'},{key:'email',label:'Email'},{key:'base_salary',label:'Salary'}]} rows={rows}/>
    </Card>
    <Card title="Set Employee Salary">
      <div className="flex flex-wrap gap-3">
        <Field label="Employee ID"><Input value={id} onChange={e=>setId(e.target.value)}/></Field>
        <Field label="Base Salary"><Input value={salary} onChange={e=>setSalary(e.target.value)}/></Field>
        <Button onClick={()=>api.admin.setEmpSalary(id, Number(salary))}>Save</Button>
      </div>
    </Card>
  </div>
}
