import React, { useEffect, useState } from 'react'
import Card from '../components/ui/Card'
import { useAuth } from '../lib/auth'
import { api } from '../lib/api'
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, LineChart, Line, YAxis, CartesianGrid } from 'recharts'

export default function Dashboard(){
  const { user } = useAuth()
  const [stats,setStats]=useState([])
  useEffect(()=>{ (async()=>{ if(user?.role==='agent'){ setStats(await api.agent.stats()) } })() },[user])

  return <div className="space-y-6">
    <div className="grid gap-4 md:grid-cols-3">
      <div className="kpi"><div className="text-sm opacity-80">Welcome</div><div className="text-xl font-bold">{user?.name || 'User'}</div><div className="tag mt-2">Role: {user?.role}</div></div>
      <div className="kpi"><div className="text-sm opacity-80">Email</div><div className="text-xl font-bold truncate">{user?.email}</div></div>
      <div className="kpi"><div className="text-sm opacity-80">ID</div><div className="text-xl font-bold truncate">{user?.id}</div></div>
    </div>
    {user?.role==='agent' && <Card title="My Monthly Sales" subtitle="Last months"><div className="h-64">
      <ResponsiveContainer width="100%" height="100%"><BarChart data={stats}><CartesianGrid strokeDasharray="3 3" strokeOpacity={0.1} /><XAxis dataKey="month" tick={{fill:'#9ca3af'}}/><YAxis tick={{fill:'#9ca3af'}}/><Tooltip contentStyle={{background:'#0f172a', border:'1px solid #1f2937', color:'#e5e7eb'}}/><Bar dataKey="sales_count" /></BarChart></ResponsiveContainer>
    </div></Card>}
    {user?.role==='agent' && <Card title="Premium vs Commission"><div className="h-64">
      <ResponsiveContainer width="100%" height="100%"><LineChart data={stats}><CartesianGrid strokeDasharray="3 3" strokeOpacity={0.1} /><XAxis dataKey="month" tick={{fill:'#9ca3af'}}/><YAxis tick={{fill:'#9ca3af'}}/><Tooltip contentStyle={{background:'#0f172a', border:'1px solid #1f2937', color:'#e5e7eb'}}/><Line type="monotone" dataKey="total_premium" /><Line type="monotone" dataKey="total_commission" /></LineChart></ResponsiveContainer>
    </div></Card>}
  </div>
}
