import React, { useState } from 'react'
import Card from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import DataTable from '../../components/data/DataTable'
import { Field } from '../../components/ui/Field'
import { Input } from '../../components/ui/Input'
import { api } from '../../lib/api'
export default function AgentCustomers(){
  const [rows,setRows]=useState([]); const [form,setForm]=useState({name:'',email:'',phone_no:''})
  async function add(){ await api.agent.addCustomer(form); setForm({name:'',email:'',phone_no:''}); setRows(await api.agent.customers()) }
  return <div className="grid gap-6 md:grid-cols-2">
    <Card title="Add Customer" actions={<Button onClick={add}>Add</Button>}>
      <div className="flex flex-wrap gap-3">
        <Field label="Name"><Input value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></Field>
        <Field label="Email"><Input value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></Field>
        <Field label="Phone"><Input value={form.phone_no} onChange={e=>setForm({...form,phone_no:e.target.value})}/></Field>
      </div>
    </Card>
    <Card title="My Customers" actions={<Button variant="outline" onClick={async()=>setRows(await api.agent.customers())}>Refresh</Button>}>
      <DataTable columns={[{key:'id',label:'ID'},{key:'name',label:'Name'},{key:'email',label:'Email'},{key:'phone_no',label:'Phone'},{key:'status',label:'Status'}]} rows={rows}/>
    </Card>
  </div>
}
