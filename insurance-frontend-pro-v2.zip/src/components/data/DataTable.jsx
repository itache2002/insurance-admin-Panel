import React, { useMemo, useState } from 'react'
import { ChevronDown, ChevronUp, Search } from 'lucide-react'
export default function DataTable({columns,rows=[]}){
  const [q,setQ]=useState(''); const [sort,setSort]=useState({key:null,dir:'asc'}); const [page,setPage]=useState(1); const pageSize=10
  const filtered=useMemo(()=>{
    const f = q? rows.filter(r=>JSON.stringify(r).toLowerCase().includes(q.toLowerCase())) : rows
    if(!sort.key) return f; const dir = sort.dir==='asc'?1:-1
    return [...f].sort((a,b)=> (a[sort.key] > b[sort.key] ? dir : -dir))
  },[q,rows,sort])
  const totalPages = Math.max(1, Math.ceil(filtered.length/pageSize)); const pageRows = filtered.slice((page-1)*pageSize, page*pageSize)
  function toggleSort(key){ setSort(s => s.key===key ? {key,dir:s.dir==='asc'?'desc':'asc'} : {key,dir:'asc'}) }
  return <div className="space-y-3">
    <div className="flex items-center justify-between gap-3">
      <div className="relative"><input className="input pl-9" placeholder="Search..." value={q} onChange={e=>{setQ(e.target.value); setPage(1)}}/><Search size={16} className="absolute left-3 top-2.5 opacity-60"/></div>
      <div className="text-xs opacity-70">{filtered.length} results</div>
    </div>
    <div className="overflow-auto rounded-xl border border-border">
      <table className="table">
        <thead className="bg-slate-900/50">
          <tr>{columns.map(c=>(<th key={c.key||c} className="th cursor-pointer select-none" onClick={()=>toggleSort(c.key||c)}>
            <div className="flex items-center gap-2"><span>{c.label||c}</span>{sort.key===(c.key||c) && (sort.dir==='asc' ? <ChevronUp size={14}/> : <ChevronDown size={14}/>)}</div>
          </th>))}</tr>
        </thead>
        <tbody>
          {pageRows.map((r,i)=>(<tr key={i} className="hover:bg-slate-800/40">
            {columns.map(c=>{ const k = c.key||c; const render = c.render; return <td key={k} className="td">{render? render(r[k], r) : r[k]}</td> })}
          </tr>))}
          {pageRows.length===0 && <tr><td className="td" colSpan={columns.length}>No results</td></tr>}
        </tbody>
      </table>
    </div>
    <div className="flex items-center justify-end gap-2">
      <button className="btn-ghost" onClick={()=>setPage(p=>Math.max(1,p-1))}>Prev</button>
      <div className="tag">Page {page} / {totalPages}</div>
      <button className="btn-ghost" onClick={()=>setPage(p=>Math.min(totalPages,p+1))}>Next</button>
    </div>
  </div>
}
