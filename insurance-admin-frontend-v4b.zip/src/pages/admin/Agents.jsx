import React, { useEffect, useState } from 'react'
import { http } from '../../lib/api'

const init = {
  name:'', email:'', phone_no:'', password:'',
  pan_number:'', aadhaar_number:'',
  bank_name:'', account_no:'', ifsc_code:'',
  tenth_percent:'', twelfth_percent:'', degree_percent:''
}

function monthFirstDay(d=new Date()){
  const y=d.getFullYear(); const m=String(d.getMonth()+1).padStart(2,'0'); return `${y}-${m}-01`
}

export default function Agents() {
  const [agents, setAgents] = useState([])
  const [form, setForm] = useState(init)
  const [saving, setSaving] = useState(false)
  const [comp, setComp] = useState({ base_salary:'', incentive_rate:'' })
  const [selected, setSelected] = useState(null)
  const [targetMap, setTargetMap] = useState({})
  const [initialPwd, setInitialPwd] = useState(null)

  async function load(){
    const data = await http('/api/admin/agents')
    setAgents(data)
  }
  useEffect(()=>{ load() }, [])

  function onChange(e){ setForm(f => ({...f, [e.target.name]: e.target.value })) }

  async function createAgent(e){
    e.preventDefault()
    setSaving(true)
    try {
      const payload = {
        ...form,
        tenth_percent: form.tenth_percent ? Number(form.tenth_percent) : undefined,
        twelfth_percent: form.twelfth_percent ? Number(form.twelfth_percent) : undefined,
        degree_percent: form.degree_percent ? Number(form.degree_percent) : undefined
      }
      const created = await http('/api/admin/agents', { method:'POST', body: payload })
      setForm(init)
      await load()
      alert('Agent created. Initial password: ' + (created.initial_password || '(hidden)'))
    } finally { setSaving(false) }
  }

  async function updateComp(e){
    e.preventDefault()
    if (!selected) return
    await http(`/api/admin/agents/${selected}/compensation`, { method:'PUT', body:{
      base_salary: Number(comp.base_salary || 0),
      incentive_rate: Number(comp.incentive_rate || 0)
    }})
    setComp({ base_salary:'', incentive_rate:'' })
    setSelected(null)
    await load()
  }

  function onTargetChange(agentId, key, value){
    setTargetMap(m => ({ ...m, [agentId]: { ...(m[agentId]||{ month: monthFirstDay(), target_value: '' , description:'' }), [key]: value } }))
  }

  async function saveTarget(agentId){
    const t = targetMap[agentId] || { month: monthFirstDay(), target_value: '', description:'' }
    if (!t.target_value) return alert('Enter a target value')
    await http(`/api/admin/agents/${agentId}/targets`, { method:'POST', body:{
      month: t.month,
      target_value: Number(t.target_value),
      description: t.description || undefined
    }})
    alert('Target saved')
  }

  async function showInitialPassword(agentId){
    try {
      const res = await http(`/api/admin/agents/${agentId}/initial-password`)
      setInitialPwd(res.initial_password + ' (expires: ' + new Date(res.expires_at).toLocaleString() + ')')
    } catch (e) {
      setInitialPwd('Not available: ' + e.message)
    }
  }

  return (
    <div className="grid gap-6">
      <div className="grid lg:grid-cols-2 gap-6">
        <form onSubmit={createAgent} className="card space-y-4">
          <div className="text-lg font-semibold">Add New Agent</div>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field name="name" label="Name" value={form.name} onChange={onChange} />
            <Field name="email" label="Email" value={form.email} onChange={onChange} />
            <Field name="phone_no" label="Phone" value={form.phone_no} onChange={onChange} />
            <Field name="password" label="Password (auto if blank)" value={form.password} onChange={onChange} />
            <Field name="pan_number" label="PAN" value={form.pan_number} onChange={onChange} />
            <Field name="aadhaar_number" label="Aadhaar" value={form.aadhaar_number} onChange={onChange} />
            <Field name="bank_name" label="Bank Name" value={form.bank_name} onChange={onChange} />
            <Field name="account_no" label="Account No" value={form.account_no} onChange={onChange} />
            <Field name="ifsc_code" label="IFSC" value={form.ifsc_code} onChange={onChange} />
            <Field name="tenth_percent" label="10th %" value={form.tenth_percent} onChange={onChange} />
            <Field name="twelfth_percent" label="12th %" value={form.twelfth_percent} onChange={onChange} />
            <Field name="degree_percent" label="Degree %" value={form.degree_percent} onChange={onChange} />
          </div>
          <button className="btn" disabled={saving}>{saving ? 'Saving…' : 'Create Agent'}</button>
          {initialPwd && <div className="text-sm text-muted">Initial password: <span className="text-white">{initialPwd}</span></div>}
        </form>

        <form onSubmit={updateComp} className="card space-y-4">
          <div className="text-lg font-semibold">Set Salary & Incentive</div>
          <div className="grid sm:grid-cols-2 gap-4">
            <select className="input select" value={selected || ''} onChange={e=>setSelected(e.target.value)}>
              <option value="">Select Agent</option>
              {agents.map(a => <option key={a.id} value={a.id}>{a.name} ({a.email})</option>)}
            </select>
            <div />
            <Field name="base_salary" label="Base Salary" value={comp.base_salary} onChange={e=>setComp({...comp, base_salary:e.target.value})} />
            <Field name="incentive_rate" label="Incentive Rate" value={comp.incentive_rate} onChange={e=>setComp({...comp, incentive_rate:e.target.value})} />
          </div>
          <button className="btn">Update Compensation</button>
        </form>
      </div>

      <div className="card">
        <div className="text-lg font-semibold mb-4">All Agents</div>
        <table className="table">
          <thead>
            <tr>
              <th className="th">Name</th>
              <th className="th">Email</th>
              <th className="th">Phone</th>
              <th className="th">PAN</th>
              <th className="th">Aadhaar</th>
              <th className="th">Bank</th>
              <th className="th">Salary</th>
              <th className="th">Incentive</th>
              <th className="th">Target (month / value)</th>
              <th className="th">Actions</th>
            </tr>
          </thead>
          <tbody>
            {agents.map(a => (
              <tr key={a.id}>
                <td className="td">{a.name}</td>
                <td className="td">{a.email}</td>
                <td className="td">{a.phone_no}</td>
                <td className="td">{a.pan_number}</td>
                <td className="td">{a.aadhaar_number}</td>
                <td className="td">{a.bank_name} • {a.account_no}</td>
                <td className="td">₹{a.base_salary ?? 0}</td>
                <td className="td">{a.incentive_rate ?? 0}</td>
                <td className="td">
                  <div className="grid sm:grid-cols-2 gap-2">
                    <input className="input" type="month" value={(targetMap[a.id]?.month || monthFirstDay()).slice(0,7)} onChange={e=>onTargetChange(a.id, 'month', e.target.value + '-01')} />
                    <input className="input" placeholder="Target value" value={targetMap[a.id]?.target_value || ''} onChange={e=>onTargetChange(a.id, 'target_value', e.target.value)} />
                    <input className="input sm:col-span-2" placeholder="Description (optional)" value={targetMap[a.id]?.description || ''} onChange={e=>onTargetChange(a.id, 'description', e.target.value)} />
                  </div>
                </td>
                <td className="td">
                  <div className="flex gap-2">
                    <button className="btn" onClick={() => saveTarget(a.id)}>Save Target</button>
                    <button className="btn-outline" onClick={() => showInitialPassword(a.id)}>Show Initial Password</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function Field({ label, ...props }){
  return (
    <div>
      <label className="label">{label}</label>
      <input className="input" {...props} />
    </div>
  )
}
