import React, { useEffect, useState } from 'react'
import { http } from '../../lib/api'
import Modal from '../../components/Modal'

export default function Customers() {
  const [rows, setRows] = useState([])
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')

  const [detailOpen, setDetailOpen] = useState(false)
  const [detail, setDetail] = useState(null)
  const [savingStatus, setSavingStatus] = useState(false)
  const [statusEdit, setStatusEdit] = useState('')

  async function load(){
    const params = new URLSearchParams()
    if (q) params.set('q', q)
    if (status) params.set('status', status)
    if (from) params.set('from', from)
    if (to) params.set('to', to)
    const data = await http('/api/admin/customers' + (params.toString()? `?${params.toString()}` : ''))
    setRows(data)
  }
  useEffect(()=>{ load() }, [])

  async function openDetail(id){
    const d = await http(`/api/admin/customers/${id}`)
    setDetail(d)
    setStatusEdit(d.status)
    setDetailOpen(true)
  }

  async function saveStatus(){
    if (!detail) return
    setSavingStatus(true)
    try {
      const updated = await http(`/api/admin/customers/${detail.id}/status`, { method: 'PATCH', body: { status: statusEdit } })
      setDetail({ ...detail, status: updated.status, updated_at: updated.updated_at })
      await load()
    } catch (e) {
      alert(e.message)
    } finally {
      setSavingStatus(false)
    }
  }

  return (
    <div className="grid gap-6">
      <div className="card grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <Field label="Search" value={q} onChange={e=>setQ(e.target.value)} placeholder="Customer or Agent name" />
        <div>
          <label className="label">Status</label>
          <select className="input select" value={status} onChange={e=>setStatus(e.target.value)}>
            <option value="">All</option>
            <option value="pending">Pending</option>
            <option value="Verified">Verified</option>
            <option value="Unverified">Unverified</option>
          </select>
        </div>
        <Field label="From" type="date" value={from} onChange={e=>setFrom(e.target.value)} />
        <Field label="To" type="date" value={to} onChange={e=>setTo(e.target.value)} />
        <div className="flex items-end">
          <button className="btn w-full" onClick={load}>Apply</button>
        </div>
      </div>

      <div className="card">
        <div className="text-lg font-semibold mb-4">All Customers</div>
        <table className="table">
          <thead>
            <tr>
              <th className="th">Customer</th>
              <th className="th">Status</th>
              <th className="th">Agent</th>
              <th className="th">Agent Email</th>
              <th className="th">Created</th>
              <th className="th">Action</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.id}>
                <td className="td">{r.customer_name}</td>
                <td className="td"><span className={`badge badge-${r.status}`}>{r.status}</span></td>
                <td className="td">{r.agent_name || '—'}</td>
                <td className="td">{r.agent_email || '—'}</td>
                <td className="td">{new Date(r.created_at).toLocaleString()}</td>
                <td className="td"><button className="btn" onClick={()=>openDetail(r.id)}>View</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal open={detailOpen} onClose={()=>setDetailOpen(false)} title="Customer Detail">
        {detail ? (
          <div className="grid gap-3">
            <div className="grid sm:grid-cols-2 gap-3">
              <KV k="Name" v={detail.name} />
              <KV k="Status" v={<span className={`badge badge-${detail.status}`}>{detail.status}</span>} />
              <KV k="Age" v={detail.age ?? '—'} />
              <KV k="Defenders Like" v={detail.defenders_like ?? '—'} />
              <KV k="No. of Children" v={detail.number_of_children ?? '—'} />
              <KV k="Spouse" v={detail.spouse ?? '—'} />
              <KV k="Parents" v={detail.parents ?? '—'} />
              <KV k="Aadhaar" v={detail.aadhaar_number ?? '—'} />
              <KV k="PAN" v={detail.pan_number ?? '—'} />
              <KV k="Created" v={new Date(detail.created_at).toLocaleString()} />
              <KV k="Updated" v={detail.updated_at ? new Date(detail.updated_at).toLocaleString() : '—'} />
              <KV k="Agent" v={`${detail.agent_name || '—'} (${detail.agent_email || ''})`} />
              <KV k="Agent Phone" v={detail.agent_phone || '—'} />
            </div>

            <div className="card">
              <div className="text-sm text-muted mb-2">Change Status (only from 'pending')</div>
              <div className="grid sm:grid-cols-[1fr_auto] gap-3">
                <select className="input select" value={statusEdit} onChange={e=>setStatusEdit(e.target.value)}>
                  <option value="pending">pending</option>
                  <option value="Verified">Verified</option>
                  <option value="Unverified">Unverified</option>
                </select>
                <button className="btn" disabled={savingStatus} onClick={saveStatus}>{savingStatus ? 'Saving…' : 'Save'}</button>
              </div>
            </div>
          </div>
        ) : 'Loading…'}
      </Modal>
    </div>
  )
}

function Field({ label, ...props }){
  return (
    <div>
      <label className="label">{label}</label>
      <input className="input" {...props} />
    </div>
  )
}
function KV({ k, v }){ return <div className="kpi"><div className="text-sm text-muted">{k}</div><div className="text-white">{v}</div></div> }
