import React, { useEffect, useState } from 'react'
import { http } from '../../lib/api'

function monthFirstDay(d=new Date()){ const y=d.getFullYear(); const m=String(d.getMonth()+1).padStart(2,'0'); return `${y}-${m}-01` }

export default function Sales() {
  const [agents, setAgents] = useState([])
  const [agentId, setAgentId] = useState('')
  const [month, setMonth] = useState(monthFirstDay())
  const [achieved_value, setAchieved] = useState('')
  const [delta, setDelta] = useState('')
  const [summary, setSummary] = useState(null)

  async function loadAgents(){ setAgents(await http('/api/admin/agents')) }
  useEffect(()=>{ loadAgents() }, [])

  async function loadSummary(){
    if (!agentId) return setSummary(null)
    const data = await http(`/api/admin/agents/${agentId}/targets/summary?month=${month}`)
    setSummary(data)
  }
  useEffect(()=>{ loadSummary() }, [agentId, month])

  async function setSales(e){
    e.preventDefault()
    if (!agentId) return alert('Select agent')
    await http(`/api/admin/agents/${agentId}/sales`, { method:'POST', body:{ month, achieved_value: Number(achieved_value||0) } })
    setAchieved('')
    await loadSummary()
    alert('Sales set')
  }

  async function incSales(e){
    e.preventDefault()
    if (!agentId) return alert('Select agent')
    await http(`/api/admin/agents/${agentId}/sales`, { method:'PATCH', body:{ month, delta: Number(delta||0) } })
    setDelta('')
    await loadSummary()
    alert('Sales incremented')
  }

  return (
    <div className="grid gap-6">
      <div className="card grid md:grid-cols-2 gap-4">
        <div>
          <label className="label">Agent</label>
          <select className="input select" value={agentId} onChange={e=>setAgentId(e.target.value)}>
            <option value="">Select Agent</option>
            {agents.map(a => <option key={a.id} value={a.id}>{a.name} ({a.email})</option>)}
          </select>
        </div>
        <div>
          <label className="label">Month</label>
          <input className="input" type="month" value={month.slice(0,7)} onChange={e=>setMonth(e.target.value+'-01')} />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <form className="card space-y-3" onSubmit={setSales}>
          <div className="text-lg font-semibold">Set Sales (Achieved)</div>
          <input className="input" placeholder="Achieved value" value={achieved_value} onChange={e=>setAchieved(e.target.value)} />
          <button className="btn">Set Sales</button>
        </form>

        <form className="card space-y-3" onSubmit={incSales}>
          <div className="text-lg font-semibold">Increment Sales</div>
          <input className="input" placeholder="Increment by (delta)" value={delta} onChange={e=>setDelta(e.target.value)} />
          <button className="btn">Increment</button>
        </form>
      </div>

      <div className="card">
        <div className="text-lg font-semibold mb-2">Current Month Summary</div>
        {summary ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <KPI title="Target" value={summary.target_value} />
            <KPI title="Achieved" value={summary.achieved_value} />
            <KPI title="Completion" value={summary.completion_pct + '%'} />
            <KPI title="Month" value={new Date(summary.month).toLocaleString('default',{ month:'long', year:'numeric'})} />
          </div>
        ) : 'Select an agent and month'}
      </div>
    </div>
  )
}

function KPI({ title, value }){
  return (<div className="kpi"><div className="text-sm text-muted">{title}</div><div className="text-2xl font-semibold">{value}</div></div>)
}
