import React, { createContext, useContext, useState } from 'react'
import { http, getCSRF } from '../lib/api'

const AuthCtx = createContext(null)
export const useAuth = () => useContext(AuthCtx)

export default function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(false)

  async function login(email, password){
    setLoading(true)
    try {
      await getCSRF()
      const { user } = await http('/api/auth/login', { method:'POST', body:{ email, password } })
      setUser(user)
      return user
    } finally { setLoading(false) }
  }

  async function logout(){
    await http('/api/auth/logout', { method:'POST' })
    setUser(null)
  }

  return <AuthCtx.Provider value={{ user, setUser, login, logout, loading }}>{children}</AuthCtx.Provider>
}
